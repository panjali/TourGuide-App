package comr.example.mypc.toursingapore;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class CategoryAdapter extends FragmentPagerAdapter {

    private String tabTitles[] = new String[] { "Things To Do", "Gardens", "Theme Parks",  "Eatery", "Shop"};

    public CategoryAdapter(FragmentManager fm) {
        super(fm);
    }
    @Override
    public android.support.v4.app.Fragment getItem(int position) {
        if (position == 0) {
            return new ThingsToDoFragment();
        } else if (position == 1){
            return new GardenFragment();
        } else if (position == 2) {
            return new ThemeParksFragment(); }
            else if (position == 3){
                return new RestaurantFragment(); }
        else {
            return new ShoppingFragment(); }
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        return tabTitles[position];
    }

}