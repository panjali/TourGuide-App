package comr.example.mypc.toursingapore;


import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class ThemeParksFragment extends Fragment {

    public ThemeParksFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_attractions, container, false);
        final ArrayList<Attractions> attractions;
        attractions = new ArrayList<Attractions>();
        Location themeparks = new Location(getResources().getString(R.string.theme_name1));
        themeparks.setLatitude(1.2816);
        themeparks.setLongitude(103.8636);

        attractions.add(new Attractions(getResources().getString(R.string.theme_name1),
                getResources().getString(R.string.theme_phone_1), getResources().getString(R.string.theme_address_1),
                getResources().getString(R.string.theme_imageurl_1),themeparks));
        attractions.add(new Attractions(getResources().getString(R.string.theme_name2),
                getResources().getString(R.string.theme_phone_2), getResources().getString(R.string.theme_address_2),
                getResources().getString(R.string.theme_imageurl_2),themeparks));
        attractions.add(new Attractions(getResources().getString(R.string.theme_name3),
                getResources().getString(R.string.theme_phone_3), getResources().getString(R.string.theme_address_3),
                getResources().getString(R.string.theme_imageurl_3),themeparks));
        attractions.add(new Attractions(getResources().getString(R.string.theme_name4),
                getResources().getString(R.string.theme_phone_4), getResources().getString(R.string.theme_address_4),
                getResources().getString(R.string.theme_imageurl_4),themeparks));
        attractions.add(new Attractions(getResources().getString(R.string.theme_name5),
                getResources().getString(R.string.theme_phone_5), getResources().getString(R.string.theme_address_5),
                getResources().getString(R.string.theme_imageurl_5),themeparks));

        AttractionAdapter adapter = new AttractionAdapter(getActivity(), attractions);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                double lat = attractions.get(position).getAtrractionLocation().getLatitude();
                double lon = attractions.get(position).getAtrractionLocation().getLongitude();
                String keyword = attractions.get(position).getAttractionName();
                Uri uri = Uri.parse("geo:" + lat + "," + lon + "?q=" + Uri.encode(keyword));

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                startActivity(intent);
            }
        });
        return rootView;
    }
}
