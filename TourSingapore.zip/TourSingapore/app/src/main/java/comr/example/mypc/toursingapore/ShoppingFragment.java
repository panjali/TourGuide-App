package comr.example.mypc.toursingapore;


import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShoppingFragment extends Fragment {


    public ShoppingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.list_attractions, container, false);
        final ArrayList<Attractions> attractions;
        attractions = new ArrayList<Attractions>();
        Location shplocation = new Location(getResources().getString(R.string.ttd_name1));
        shplocation.setLatitude(1.2816);
        shplocation.setLongitude(103.8636);

        attractions.add(new Attractions(getResources().getString(R.string.shp_name1),
                getResources().getString(R.string.shp_phone_1), getResources().getString(R.string.shp_address_1),
                getResources().getString(R.string.shp_imageurl_1),shplocation));

        attractions.add(new Attractions(getResources().getString(R.string.shp_name2),
                getResources().getString(R.string.shp_phone_2), getResources().getString(R.string.shp_address_2),
                getResources().getString(R.string.shp_imageurl_2),shplocation));

        attractions.add(new Attractions(getResources().getString(R.string.shp_name3),
                getResources().getString(R.string.shp_phone_3), getResources().getString(R.string.shp_address_3),
                getResources().getString(R.string.shp_imageurl_3),shplocation));

        AttractionAdapter adapter = new AttractionAdapter(getActivity(), attractions);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                double lat = attractions.get(position).getAtrractionLocation().getLatitude();
                double lon = attractions.get(position).getAtrractionLocation().getLongitude();
                String keyword = attractions.get(position).getAttractionName();
                Uri uri = Uri.parse("geo:" + lat + "," + lon + "?q=" + Uri.encode(keyword));

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                startActivity(intent);
            }
        });
        return rootView;
    }
}
