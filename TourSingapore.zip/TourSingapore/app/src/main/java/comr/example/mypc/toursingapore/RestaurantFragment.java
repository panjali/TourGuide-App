package comr.example.mypc.toursingapore;


import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class RestaurantFragment extends Fragment {
    public RestaurantFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.list_attractions, container, false);

        final ArrayList<Attractions> attractions;
        attractions = new ArrayList<Attractions>();
        Location reslocation = new Location(getResources().getString(R.string.res_name1));
        reslocation.setLatitude(1.2816);
        reslocation.setLongitude(103.8636);

        attractions.add(new Attractions(getResources().getString(R.string.res_name1),
                getResources().getString(R.string.res_phone_1), getResources().getString(R.string.res_address_1),
                getResources().getString(R.string.res_imageurl_1), reslocation));
        attractions.add(new Attractions(getResources().getString(R.string.res_name2),
                getResources().getString(R.string.res_phone_2), getResources().getString(R.string.res_address_2),
                getResources().getString(R.string.res_imageurl_2), reslocation));
        attractions.add(new Attractions(getResources().getString(R.string.res_name3),
                getResources().getString(R.string.res_phone_3), getResources().getString(R.string.res_address_3),
                getResources().getString(R.string.res_imageurl_3), reslocation));
        attractions.add(new Attractions(getResources().getString(R.string.res_name4),
                getResources().getString(R.string.res_phone_4), getResources().getString(R.string.res_address_4),
                getResources().getString(R.string.res_imageurl_4), reslocation));
        attractions.add(new Attractions(getResources().getString(R.string.res_name5),
                getResources().getString(R.string.res_phone_5), getResources().getString(R.string.res_address_5),
                getResources().getString(R.string.res_imageurl_5), reslocation));

        AttractionAdapter adapter = new AttractionAdapter(getActivity(), attractions);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                double lat = attractions.get(position).getAtrractionLocation().getLatitude();
                double lon = attractions.get(position).getAtrractionLocation().getLongitude();
                String keyword = attractions.get(position).getAttractionName();
                Uri uri = Uri.parse("geo:" + lat + "," + lon + "?q=" + Uri.encode(keyword));

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                startActivity(intent);
            }
        });
        return rootView;
    }
}

